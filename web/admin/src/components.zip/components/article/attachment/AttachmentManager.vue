<template>
    <div class="attachment-manager">
      <h3>文件附件</h3>
      
      <!-- 上传区域 -->
      <div class="upload-section">
        <a-upload
          :multiple="true"
          :action="uploadUrl"
          :headers="headers"
          :data="{ article_id: articleId }"
          :fileList="fileList"
          @change="handleChange"
          @remove="handleRemove"
        >
          <a-button type="primary" :disabled="!articleId">
            <a-icon type="upload" /> 上传附件
          </a-button>
          <span class="upload-hint" v-if="!articleId">请先保存文章后再上传附件</span>
        </a-upload>
      </div>
      
      <!-- 附件列表 -->
      <div class="attachment-list" v-if="attachments.length > 0">
        <h4>已上传附件列表</h4>
        <a-table :dataSource="attachments" :columns="columns" rowKey="id" size="small">
          <template slot="action" slot-scope="text, record">
            <a-button type="link" @click="downloadAttachment(record.id, record.fileName)">
              <a-icon type="download" /> 下载
            </a-button>
            <a-button type="link" @click="deleteAttachment(record.id)" class="delete-btn">
              <a-icon type="delete" /> 删除
            </a-button>
          </template>
          <template slot="fileSize" slot-scope="text">
            {{ formatFileSize(text) }}
          </template>
        </a-table>
      </div>
    </div>
  </template>
  
  <script>
  import { Url } from '../../../plugin/http'
  
  export default {
    props: {
      articleId: {
        type: [Number, String],
        default: 0
      }
    },
    
    data() {
      return {
        uploadUrl: Url + 'attachment/upload',
        headers: {},
        fileList: [],
        attachments: [],
        columns: [
          {
            title: '文件名',
            dataIndex: 'fileName',
            key: 'fileName',
          },
          {
            title: '类型',
            dataIndex: 'fileType',
            key: 'fileType',
          },
          {
            title: '大小',
            dataIndex: 'fileSize',
            key: 'fileSize',
            scopedSlots: { customRender: 'fileSize' },
          },
          {
            title: '操作',
            key: 'action',
            scopedSlots: { customRender: 'action' },
          }
        ]
      }
    },
    
    mounted() {
      this.headers = { Authorization: `Bearer ${window.sessionStorage.getItem('token')}` }
      
      if (this.articleId && this.articleId > 0) {
        this.getAttachments()
      }
    },
    
    watch: {
      articleId(newVal) {
        if (newVal && newVal > 0) {
          this.getAttachments()
        } else {
          this.attachments = []
        }
      }
    },
    
    methods: {
      // 获取文章附件列表
      async getAttachments() {
        if (!this.articleId) return
        
        try {
          const { data: res } = await this.$http.get(`attachment/${this.articleId}`)
          if (res.status !== 200) {
            this.$message.error(res.message)
            return
          }
          
          this.attachments = res.data
        } catch (error) {
          this.$message.error('获取附件列表失败')
          console.error(error)
        }
      },
      
      // 处理上传状态变化
      handleChange(info) {
        let fileList = [...info.fileList]
        
        // 限制只展示最近上传的文件
        fileList = fileList.slice(-5)
        
        // 更新状态
        this.fileList = fileList
        
        // 处理上传状态
        if (info.file.status === 'done') {
          if (info.file.response.status === 200) {
            this.$message.success(`${info.file.name} 上传成功`)
            // 刷新附件列表
            this.getAttachments()
          } else {
            this.$message.error(`${info.file.name} 上传失败: ${info.file.response.message}`)
          }
        } else if (info.file.status === 'error') {
          this.$message.error(`${info.file.name} 上传失败`)
        }
      },
      
      // 下载附件
      downloadAttachment(id, fileName) {
        window.open(`${Url}attachment/download/${id}`, '_blank')
      },
      
      // 删除附件
      async deleteAttachment(id) {
        try {
          const { data: res } = await this.$http.delete(`attachment/${id}`)
          if (res.status !== 200) {
            this.$message.error(res.message)
            return
          }
          
          this.$message.success('附件删除成功')
          this.getAttachments()
        } catch (error) {
          this.$message.error('删除附件失败')
          console.error(error)
        }
      },
      
      // 移除上传列表中的文件
      handleRemove(file) {
        const index = this.fileList.indexOf(file)
        const newFileList = this.fileList.slice()
        newFileList.splice(index, 1)
        this.fileList = newFileList
      },
      
      // 格式化文件大小
      formatFileSize(size) {
        if (size < 1024) {
          return size + ' B'
        } else if (size < 1024 * 1024) {
          return (size / 1024).toFixed(2) + ' KB'
        } else if (size < 1024 * 1024 * 1024) {
          return (size / (1024 * 1024)).toFixed(2) + ' MB'
        } else {
          return (size / (1024 * 1024 * 1024)).toFixed(2) + ' GB'
        }
      }
    }
  }
  </script>
  
  <style scoped>
  .attachment-manager {
    margin-top: 20px;
    padding: 20px;
    background-color: #fafafa;
    border-radius: 4px;
  }
  
  .upload-section {
    margin-bottom: 20px;
  }
  
  .upload-hint {
    margin-left: 10px;
    color: #ff4d4f;
  }
  
  .attachment-list {
    margin-top: 20px;
  }
  
  .delete-btn {
    color: #ff4d4f;
  }
  </style>